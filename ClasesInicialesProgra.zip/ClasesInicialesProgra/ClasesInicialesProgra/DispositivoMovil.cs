﻿using System;

//El namespace es un agrupador de clases y permite organizarlas
namespace ClasesInicialesProgra
{
    public class DispositivoMovil
    {
        public int ram;
        public int almacenamiento;
        public float tamaño;
        public int ResoluAncho;
        public int resoluAlto;
        public Color color;
    }
}
